export interface Goal {
  id: string;
  title: string;
  description: string;
  category: 'health' | 'fitness' | 'productivity' | 'wellness';
  progress: number; // 0-100
  target: number;
  unit: string;
  icon: string;
  color: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  frequency: 'daily' | 'weekly';
  completed: boolean;
  completedDates: string[]; // ISO date strings
  points: number;
  icon: string;
  color: string;
}

export interface User {
  id: string;
  name: string;
  level: number;
  currentStreak: number;
  totalPoints: number;
  wellnessScore: number; // 0-100
  avatar: string;
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  pointsRequired: number;
  discount: string;
  category: 'insurance' | 'health' | 'wellness' | 'lifestyle';
  unlocked: boolean;
  icon: string;
}
