import React, { useState, useMemo } from 'react';
import { Goal, Task, User } from '../types';
import UserCard from '../components/Dashboard/UserCard';
import GoalCard from '../components/Dashboard/GoalCard';
import TaskItem from '../components/Dashboard/TaskItem';
import { ChevronRight, Calendar, Zap } from 'lucide-react';

// Sample data
const initialUser: User = {
  id: '1',
  name: 'Ahmed',
  level: 5,
  currentStreak: 12,
  totalPoints: 2840,
  wellnessScore: 78,
  avatar: '👤',
};

const initialGoals: Goal[] = [
  {
    id: '1',
    title: 'Daily Steps',
    description: 'Walk 10,000 steps for better health',
    category: 'fitness',
    progress: 8500,
    target: 10000,
    unit: 'steps',
    icon: '👟',
    color: 'blue',
    completed: false,
  },
  {
    id: '2',
    title: 'Drink Water',
    description: 'Stay hydrated throughout the day',
    category: 'health',
    progress: 6,
    target: 8,
    unit: 'glasses',
    icon: '💧',
    color: 'blue',
    completed: true,
  },
  {
    id: '3',
    title: 'Meditation',
    description: 'Mindfulness session for mental wellness',
    category: 'wellness',
    progress: 20,
    target: 30,
    unit: 'min',
    icon: '🧘',
    color: 'purple',
    completed: false,
  },
  {
    id: '4',
    title: 'Healthy Eating',
    description: 'Eat balanced meals with vegetables',
    category: 'health',
    progress: 5,
    target: 5,
    unit: 'meals',
    icon: '🥗',
    color: 'green',
    completed: true,
  },
  {
    id: '5',
    title: 'Reading',
    description: 'Read pages for mental enrichment',
    category: 'productivity',
    progress: 45,
    target: 50,
    unit: 'pages',
    icon: '📚',
    color: 'orange',
    completed: false,
  },
];

const initialTasks: Task[] = [
  {
    id: 't1',
    title: 'Morning Exercise',
    description: '30 mins of cardio or yoga',
    frequency: 'daily',
    completed: false,
    completedDates: [],
    points: 100,
    icon: '🏃',
    color: 'green',
  },
  {
    id: 't2',
    title: 'Healthy Breakfast',
    description: 'Eat a nutritious breakfast',
    frequency: 'daily',
    completed: false,
    completedDates: [],
    points: 50,
    icon: '🥣',
    color: 'blue',
  },
  {
    id: 't3',
    title: 'Meditation',
    description: '10 mins of mindfulness',
    frequency: 'daily',
    completed: false,
    completedDates: [],
    points: 75,
    icon: '🧘',
    color: 'purple',
  },
  {
    id: 't4',
    title: 'Evening Walk',
    description: 'Relax with a 20-min walk',
    frequency: 'daily',
    completed: false,
    completedDates: [],
    points: 80,
    icon: '🚶',
    color: 'pink',
  },
  {
    id: 't5',
    title: 'Weekly Gym Session',
    description: 'Complete a full body workout',
    frequency: 'weekly',
    completed: false,
    completedDates: [],
    points: 200,
    icon: '🏋️',
    color: 'orange',
  },
];

const Dashboard: React.FC = () => {
  const [goals, setGoals] = useState<Goal[]>(initialGoals);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [user, setUser] = useState<User>(initialUser);

  const today = new Date().toISOString().split('T')[0];

  const handleToggleGoal = (goalId: string) => {
    setGoals(
      goals.map((goal) =>
        goal.id === goalId
          ? { ...goal, completed: !goal.completed }
          : goal
      )
    );

    // Update user points and wellness score
    const goal = goals.find((g) => g.id === goalId);
    if (goal && !goal.completed) {
      setUser((prev) => ({
        ...prev,
        totalPoints: prev.totalPoints + 150,
        wellnessScore: Math.min(prev.wellnessScore + 5, 100),
      }));
    }
  };

  const handleToggleTask = (taskId: string) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          const isCompletedToday = task.completedDates.includes(today);
          const updatedTask = {
            ...task,
            completed: !isCompletedToday,
            completedDates: isCompletedToday
              ? task.completedDates.filter((d) => d !== today)
              : [...task.completedDates, today],
          };

          // Update user points and streak
          if (!isCompletedToday) {
            setUser((prev) => ({
              ...prev,
              totalPoints: prev.totalPoints + task.points,
              wellnessScore: Math.min(prev.wellnessScore + 3, 100),
            }));
          }

          return updatedTask;
        }
        return task;
      })
    );
  };

  const completedGoalCount = goals.filter((g) => g.completed).length;
  const completedTasksToday = tasks.filter((t) =>
    t.completedDates.includes(today)
  ).length;
  const totalTasksPoints = tasks
    .filter((t) => t.completedDates.includes(today))
    .reduce((sum, t) => sum + t.points, 0);

  return (
    <div className="min-h-screen pb-12">
      {/* Header */}
      <header className="bg-white sticky top-0 z-50 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-4xl">💚</div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">QIC LifePlus</h1>
                <p className="text-sm text-gray-600">Your wellness & rewards hub</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-purple-600">{user.totalPoints}</p>
              <p className="text-xs text-gray-600">Total Points</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User Card */}
        <UserCard user={user} />

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="card">
            <div className="flex items-center gap-3">
              <div className="text-3xl">📊</div>
              <div>
                <p className="text-sm text-gray-600">Monthly Goals</p>
                <p className="text-2xl font-bold text-purple-600">
                  {completedGoalCount}/{goals.length}
                </p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3">
              <div className="text-3xl">✅</div>
              <div>
                <p className="text-sm text-gray-600">Today's Tasks</p>
                <p className="text-2xl font-bold text-blue-600">
                  {completedTasksToday}/{tasks.filter((t) => t.frequency === 'daily').length}
                </p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3">
              <div className="text-3xl">⚡</div>
              <div>
                <p className="text-sm text-gray-600">Points Today</p>
                <p className="text-2xl font-bold text-orange-600">+{totalTasksPoints}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Goals Section */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Calendar className="w-6 h-6 text-purple-600" />
              <h2 className="text-2xl font-bold text-gray-900">Monthly Goals</h2>
            </div>
            <a href="#" className="flex items-center gap-1 text-purple-600 hover:text-purple-700 font-semibold">
              View All <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {goals.map((goal) => (
              <GoalCard
                key={goal.id}
                goal={goal}
                onToggle={handleToggleGoal}
              />
            ))}
          </div>
        </section>

        {/* Weekly Achievements Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Zap className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">Daily Tasks</h2>
            </div>
            <a href="#" className="flex items-center gap-1 text-blue-600 hover:text-blue-700 font-semibold">
              View Streak <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          <div className="space-y-3">
            {tasks.map((task) => {
              const isCompletedToday = task.completedDates.includes(today);
              return (
                <TaskItem
                  key={task.id}
                  task={task}
                  onToggle={handleToggleTask}
                  isCompletedToday={isCompletedToday}
                />
              );
            })}
          </div>

          {/* Motivational message */}
          <div className="mt-8 p-6 bg-gradient-to-r from-green-100 to-blue-100 rounded-2xl border-l-4 border-green-500">
            <p className="text-lg font-semibold text-gray-800 mb-2">🎉 Great Progress!</p>
            <p className="text-gray-700">
              You're {completedTasksToday > 0 ? 'doing amazing today!' : 'off to a good start. Complete your first task to build momentum!'}
            </p>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
