import React from 'react';
import { Flame, Zap, Trophy } from 'lucide-react';
import { User } from '../../types';

interface UserCardProps {
  user: User;
}

const UserCard: React.FC<UserCardProps> = ({ user }) => {
  return (
    <div className="card-elevated bg-gradient-to-br from-purple-600 to-blue-600 text-white mb-8">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Welcome, {user.name}! 👋</h1>
          <p className="text-purple-100">Keep up your wellness journey</p>
        </div>
        <div className="text-5xl">😊</div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Streak */}
        <div className="bg-white bg-opacity-20 rounded-xl p-4 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-2">
            <Flame className="w-5 h-5 text-orange-300" />
            <p className="text-sm text-purple-100">Current Streak</p>
          </div>
          <p className="text-2xl font-bold">{user.currentStreak}</p>
          <p className="text-xs text-purple-100">days</p>
        </div>

        {/* Level */}
        <div className="bg-white bg-opacity-20 rounded-xl p-4 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="w-5 h-5 text-yellow-300" />
            <p className="text-sm text-purple-100">Level</p>
          </div>
          <p className="text-2xl font-bold">{user.level}</p>
          <p className="text-xs text-purple-100">wellness master</p>
        </div>

        {/* Points */}
        <div className="bg-white bg-opacity-20 rounded-xl p-4 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-yellow-300" />
            <p className="text-sm text-purple-100">Total Points</p>
          </div>
          <p className="text-2xl font-bold">{user.totalPoints}</p>
          <p className="text-xs text-purple-100">earned</p>
        </div>
      </div>

      {/* Wellness Score */}
      <div className="mt-6 pt-6 border-t border-white border-opacity-20">
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm font-semibold text-purple-100">Your Wellness Score</span>
          <span className="text-2xl font-bold">{user.wellnessScore}%</span>
        </div>
        <div className="w-full bg-white bg-opacity-20 rounded-full h-3 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-green-400 to-blue-300 rounded-full transition-all duration-500"
            style={{ width: `${user.wellnessScore}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default UserCard;
