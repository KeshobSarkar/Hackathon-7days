import React from 'react';
import { Task } from '../../types';
import { Check, Zap } from 'lucide-react';

interface TaskItemProps {
  task: Task;
  onToggle: (taskId: string) => void;
  isCompletedToday: boolean;
}

const categoryIcons: Record<string, string> = {
  daily: '☀️',
  weekly: '📅',
};

const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, isCompletedToday }) => {
  const colorClasses = {
    green: 'text-green-600',
    blue: 'text-blue-600',
    pink: 'text-pink-600',
    orange: 'text-orange-600',
    purple: 'text-purple-600',
  };

  const bgClasses = {
    green: 'bg-green-50 hover:bg-green-100',
    blue: 'bg-blue-50 hover:bg-blue-100',
    pink: 'bg-pink-50 hover:bg-pink-100',
    orange: 'bg-orange-50 hover:bg-orange-100',
    purple: 'bg-purple-50 hover:bg-purple-100',
  };

  const color = task.color as keyof typeof colorClasses;

  return (
    <div
      className={`flex items-center justify-between p-4 rounded-xl transition-all duration-200 cursor-pointer border-l-4 ${
        bgClasses[color]
      } ${isCompletedToday ? `border-green-500 bg-green-100` : `border-${task.color}-300`}`}
      onClick={() => onToggle(task.id)}
    >
      <div className="flex items-center gap-4 flex-1">
        <div className="text-2xl">{categoryIcons[task.frequency] || '📋'}</div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h4 className={`font-semibold text-gray-800 ${isCompletedToday ? 'line-through text-gray-500' : ''}`}>
              {task.title}
            </h4>
            {isCompletedToday && (
              <Check className="w-5 h-5 text-green-600" />
            )}
          </div>
          <p className="text-sm text-gray-600">{task.description}</p>
        </div>
      </div>

      <div className="flex items-center gap-3 ml-4">
        <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-lg">
          <Zap className={`w-4 h-4 ${colorClasses[color]}`} />
          <span className="text-sm font-semibold text-gray-700">+{task.points}</span>
        </div>

        <button
          className={`flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
            isCompletedToday
              ? 'bg-green-500 border-green-500'
              : `border-gray-300 hover:border-${task.color}-500`
          }`}
          onClick={(e) => {
            e.stopPropagation();
            onToggle(task.id);
          }}
        >
          {isCompletedToday && <span className="text-white font-bold text-sm">✓</span>}
        </button>
      </div>
    </div>
  );
};

export default TaskItem;
