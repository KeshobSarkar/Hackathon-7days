import React from 'react';
import { Goal } from '../../types';

interface GoalCardProps {
  goal: Goal;
  onToggle: (goalId: string) => void;
}

const colorMap: Record<string, { bg: string; text: string; progress: string }> = {
  green: { bg: 'bg-green-100', text: 'text-green-700', progress: 'bg-green-500' },
  blue: { bg: 'bg-blue-100', text: 'text-blue-700', progress: 'bg-blue-500' },
  pink: { bg: 'bg-pink-100', text: 'text-pink-700', progress: 'bg-pink-500' },
  orange: { bg: 'bg-orange-100', text: 'text-orange-700', progress: 'bg-orange-500' },
  purple: { bg: 'bg-purple-100', text: 'text-purple-700', progress: 'bg-purple-500' },
};

const categoryIcons: Record<string, string> = {
  health: '🏥',
  fitness: '💪',
  productivity: '📚',
  wellness: '🧘',
};

const GoalCard: React.FC<GoalCardProps> = ({ goal, onToggle }) => {
  const color = colorMap[goal.color] || colorMap.blue;
  const percentage = Math.min((goal.progress / goal.target) * 100, 100);

  return (
    <div className="goal-card card group relative overflow-hidden">
      {/* Background glow effect */}
      <div className={`absolute top-0 right-0 w-20 h-20 ${color.bg} rounded-full blur-2xl opacity-0 group-hover:opacity-50 transition-opacity duration-300`} />

      <div className="relative">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="text-3xl">{categoryIcons[goal.category] || '🎯'}</span>
              <div>
                <h3 className="font-bold text-lg text-gray-800">{goal.title}</h3>
                <p className="text-sm text-gray-500">{goal.description}</p>
              </div>
            </div>
          </div>
          <button
            onClick={() => onToggle(goal.id)}
            className={`flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
              goal.completed
                ? 'bg-green-500 border-green-500'
                : `border-gray-300 hover:border-${goal.color}-500`
            }`}
          >
            {goal.completed && <span className="text-white font-bold">✓</span>}
          </button>
        </div>

        {/* Progress bar */}
        <div className="mb-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-semibold text-gray-600">Progress</span>
            <span className={`text-sm font-bold ${color.text}`}>
              {goal.progress} / {goal.target} {goal.unit}
            </span>
          </div>
          <div className="progress-bar bg-gray-200">
            <div
              className={`progress-fill ${color.progress}`}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>

        {/* Status badge */}
        <div className="flex gap-2">
          {goal.completed && (
            <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
              ✓ Completed
            </span>
          )}
          {!goal.completed && percentage >= 75 && (
            <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">
              Almost there!
            </span>
          )}
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700">
            {Math.round(percentage)}%
          </span>
        </div>
      </div>
    </div>
  );
};

export default GoalCard;
